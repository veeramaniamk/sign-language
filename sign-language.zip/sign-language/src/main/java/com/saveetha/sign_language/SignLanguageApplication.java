package com.saveetha.sign_language;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SignLanguageApplication {

	public static void main(String[] args) {
		SpringApplication.run(SignLanguageApplication.class, args);
	}

}
