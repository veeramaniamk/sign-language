package com.saveetha.sign_language;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SignLanguageApplicationTests {

	@Test
	void contextLoads() {
	}

}
